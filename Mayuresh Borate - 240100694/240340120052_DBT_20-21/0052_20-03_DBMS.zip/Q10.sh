#!/bin/bash

echo " Task 10 : "
if [ "$#" -eq 0 ]; then
	echo "Usage :$0 <file1> [<file2> ...]"
	exit 1
fi
for file in "$@";do
	if [ ! -e "$file" ] ; then
	  	echo "$file : No such file or directory. "
	elif [ -f "$file" ]; then
		echo "$file: Regular file "
	elif [ -d "$file" ]; then
		echo "$file: Directory "
	elif [ -h "$file" ]; then 
		echo  "$file: Symbolic link "
	elif [ -p "$file" ]; then
		echo "$file: Named pipe (FIFO) "
	elif [ -c "$file" ]; then
		echo "$file: Character device "
	elif [ -b "$file" ] ; then
		echo "$file : Block device " 
	else 
		echo "$file : Unknown file type "
	fi
done

