#!/bin/bash


echo "Number of arguments : $#"
echo "script name : $0"
echo "second argument : $2"
echo " argument passed : $@"

