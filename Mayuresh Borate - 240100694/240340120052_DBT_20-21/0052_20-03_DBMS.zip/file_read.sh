#!/bin/bash

read -p "Enter file name : " filename

while read line
do 
	echo "$line"
done < $filename

c=$(cat $filename | wc -c)

w=$(cat $filename | wc -w)

echo "no. of char :  $c"

echo "no. of word :  $w"

