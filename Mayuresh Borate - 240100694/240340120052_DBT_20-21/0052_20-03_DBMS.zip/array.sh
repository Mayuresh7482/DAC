#!/bin/bash
myarray=(1 2 hello "Hello world")
echo "${myarray[0]}"
echo "${myarray[*]}"

echo "Lenght : ${myarray[*]}"
echo "${myarray[*]:1}"
echo "${myarray[*]:1:2}"
myarray+=(5 4 arvind)
echo "${myarray[*]}"

